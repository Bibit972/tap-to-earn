# tap-to-earn
TAP TO EARN is afree Andriod app that allows users to earn real money by comg simple tasks such as watching ads, checking in daily, and referring friends. Designed with a clean and user - freindly interface, TAP TO EARN provides an easy way for user to earn rewards from anywhere.
